package edu.sjsu.cs249.abd;

import edu.sjsu.cs249.abd.Grpc.*;
import io.grpc.Context;
import io.grpc.stub.StreamObserver;

import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//public class ServerService {

//    @CommandLine.Command(subcommands = { ServerCli.class})
//    static class Cli {}
//    @CommandLine.Command(name = "server", mixinStandardHelpOptions = true, description = "abd server for class.")
//    static class ServerCli implements Callable<Integer> {
//
//        @CommandLine.Parameters(index = "0", description = "port to connect listen on.")
//        int port;

        public class MyServerService extends edu.sjsu.cs249.abd.ABDServiceGrpc.ABDServiceImplBase{

            boolean read1 = true;
            boolean read2 = true;
            boolean write = true;

            Map<Long, List<Long>> serverHashMap = new HashMap<>();



            @Override
            public void name(NameRequest request, StreamObserver<NameResponse> responseObserver) {
                System.out.println("Name Request Received");
                responseObserver.onNext(NameResponse.newBuilder().setName("Anant Shukla").build());
                responseObserver.onCompleted();
            }

            @Override
            public void enableRequests(EnableRequest request, StreamObserver<EnableResponse> responseObserver) {
                this.read1 = request.getRead1();
                this.read2 = request.getRead2();
                this.write = request.getWrite();
                responseObserver.onNext(EnableResponse.newBuilder().build());
                responseObserver.onCompleted();
            }

            @Override
            public void write(WriteRequest request, StreamObserver<WriteResponse> responseObserver){
                System.out.println("Got Write Request");
                if (this.write) {
                    System.out.println("Write Requests Enabled. Proceeding...");
                    Long address = request.getAddr();
                    Long timestamp = request.getLabel();
                    Long value = request.getValue();

                    //Log to console
                    System.out.println(address);
                    System.out.println(timestamp);
                    System.out.println(value);

                    //commit to memory
                    List<Long> timestampAndValue = new ArrayList<Long>();
                    timestampAndValue.add(timestamp);
                    timestampAndValue.add(value);

                    serverHashMap.put(address,timestampAndValue);
                    responseObserver.onNext(WriteResponse.newBuilder().build());
                    responseObserver.onCompleted();
                }
            }
            @Override
            public void read1(Read1Request request, StreamObserver<Read1Response> responseObserver) {
                if (this.read1) {
                    Long address = request.getAddr();
                    System.out.println(address);

                    //pass
                    if (serverHashMap.containsKey(address)){
                        List<Long> innerList= serverHashMap.get(address);
                        Long timestamp = innerList.get(0);
                        Long value =  innerList.get(1);
                        responseObserver.onNext(Read1Response.newBuilder()
                                .setRc(0)
                                .setLabel(timestamp)
                                .setValue(value)
                                .build());
                    }
                    //fail
                    else {
                        responseObserver.onNext(Read1Response.newBuilder().setRc(1)
                                .build());
                    }
                    responseObserver.onCompleted();
                }
            }

            @Override
            public void read2(Read2Request request, StreamObserver<Read2Response> responseObserver) {
                if(this.read2) {
                    Long address = request.getAddr();
                    Long timestamp = request.getLabel();
                    Long value = request.getValue();

                    //Log to console
                    System.out.println(address);
                    System.out.println(timestamp);
                    System.out.println(value);

                    if(serverHashMap.containsKey(address)){
                        List<Long> innerList= serverHashMap.get(address);
                        Long listTimestamp = innerList.get(0);

                        if (listTimestamp<timestamp){
                            innerList.set(0,timestamp);
                            innerList.set(1,value);
                            serverHashMap.put(address,innerList);
                        }
                    }

                    responseObserver.onNext(Read2Response.newBuilder().build());
                    responseObserver.onCompleted();
                }
            }

            @Override
            public void exit(ExitRequest request, StreamObserver<ExitResponse> responseObserver) {
                responseObserver.onNext(ExitResponse.newBuilder().build());
                responseObserver.onCompleted();
                System.exit(0);
            }



        static private Context.Key<SocketAddress> REMOTE_ADDR = Context.key("REMOTE_ADDR");
//        @Override
//        public Integer call() throws Exception {
//            System.out.printf("listening on %d\n", port);
//            var server = ServerBuilder.forPort(port).intercept(new ServerInterceptor() {
//                @Override
//                public <ReqT, RespT> ServerCall.Listener<ReqT> interceptCall(ServerCall<ReqT, RespT> sc, Metadata h,
//                                                                             ServerCallHandler<ReqT, RespT> next) {
//                    var remote = sc.getAttributes().get(TRANSPORT_ATTR_REMOTE_ADDR);
//                    return Contexts.interceptCall(Context.current().withValue(REMOTE_ADDR, remote),
//                            sc, h, next);
//                }
//            }).addService(new MyServerService()).build();
//            server.start();
//            server.awaitTermination();
//            return 0;
//        }
//    }
//
//    public static void main(String[] args) {
//        System.exit(new CommandLine(new Cli()).execute(args));
//    }
}